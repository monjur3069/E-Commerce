package com.example.ecom_admin_batch06

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
